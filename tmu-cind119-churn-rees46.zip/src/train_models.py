import argparse
import os
import json
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.metrics import classification_report, confusion_matrix, roc_auc_score
from sklearn.tree import DecisionTreeClassifier
from sklearn.naive_bayes import GaussianNB
from imblearn.over_sampling import SMOTE

RANDOM_STATE = 42

def load_data(path):
    df = pd.read_csv(path)
    if 'target_event' not in df.columns:
        raise ValueError('Expected binary target column "target_event" not found.')
    y = df['target_event'].astype(int)
    X = df.drop(columns=['target_event'])
    return X, y

def build_pipelines(X):
    num_cols = X.select_dtypes(include=[np.number]).columns.tolist()
    preproc_nb = ColumnTransformer([('scale', StandardScaler(with_mean=False), num_cols)], remainder='drop')
    pipe_nb = Pipeline([('pre', preproc_nb), ('clf', GaussianNB())])

    pipe_dt = Pipeline([('clf', DecisionTreeClassifier(random_state=RANDOM_STATE, max_depth=None))])
    return pipe_dt, pipe_nb

def main(data_path, out_dir):
    os.makedirs(out_dir, exist_ok=True)
    X, y = load_data(data_path)

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=RANDOM_STATE, stratify=y
    )

    # Optional SMOTE (only on train)
    smote = SMOTE(random_state=RANDOM_STATE)
    X_train_res, y_train_res = smote.fit_resample(X_train, y_train)

    pipe_dt, pipe_nb = build_pipelines(X)

    # Train & evaluate
    results = {}
    for name, pipe in [('decision_tree', pipe_dt), ('naive_bayes', pipe_nb)]:
        pipe.fit(X_train_res, y_train_res)
        y_pred = pipe.predict(X_test)
        y_prob = None
        try:
            y_prob = pipe.predict_proba(X_test)[:,1]
        except Exception:
            pass

        report = classification_report(y_test, y_pred, output_dict=True)
        cm = confusion_matrix(y_test, y_pred).tolist()
        auc = float(roc_auc_score(y_test, y_prob)) if y_prob is not None else None

        results[name] = {
            'classification_report': report,
            'confusion_matrix': cm,
            'roc_auc': auc
        }

    with open(os.path.join(out_dir, 'metrics.json'), 'w') as f:
        json.dump(results, f, indent=2)

    print(json.dumps(results, indent=2))

if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--data_path', type=str, required=True, help='Path to rees46_customer_model.csv')
    ap.add_argument('--out_dir', type=str, default='./results')
    args = ap.parse_args()
    main(args.data_path, args.out_dir)

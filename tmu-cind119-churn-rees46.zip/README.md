# CIND119 – E‑Commerce Churn Prediction (REES46)

This repository contains code and results for predicting customer churn using the **REES46** customer‑level e‑commerce dataset. The project emphasizes **interpretable models** (Decision Tree and Naïve Bayes) and follows TMU Milestone‑2 expectations (Literature Review, Data Description, and Project Approach).

## 🧰 Tech Stack
Python 3.10+, pandas, scikit‑learn, imbalanced‑learn, matplotlib

## 📦 Data
- **Source:** REES46 E‑Commerce Churn (Kaggle). See `data/DATA_SOURCES.md` for the official link and license.
- **Note:** Do not commit large/raw datasets. Include only small samples if needed.

## 🔎 Problem
Predict which customers will churn (binary label: `target_event`) based on behaviour features (recency, frequency, monetary, session patterns).

## 🧪 Methods
- **Models:** DecisionTreeClassifier, GaussianNB
- **Preprocessing:** train/test split, optional scaling for NB, SMOTE/class weights if imbalance
- **Metrics:** Accuracy, Precision, Recall, F1, ROC‑AUC
- **Interpretability:** Tree feature importance; correlation and recency analysis

## 🚀 Quickstart
```bash
# (1) Create environment
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt

# (2) Put dataset under ./data (or mount path) and set DATA_PATH below
python src/train_models.py --data_path ./data/rees46_customer_model.csv --out_dir ./results
```

## 📁 Repo Layout
```
.
├─ data/                 # data files (excluded by .gitignore)
│  └─ DATA_SOURCES.md    # links and license notes
├─ notebooks/            # optional EDA or report notebooks
├─ src/                  # training/evaluation scripts
│  └─ train_models.py
├─ figures/              # exported plots
├─ results/              # model outputs & metrics
├─ requirements.txt
├─ README.md
└─ LICENSE
```

## 📝 Reproducibility Notes
- `train_models.py` prints a concise metrics table and saves confusion matrices/ROC where applicable.
- Random seed fixed for comparability.
- See `results/` for artifacts and `figures/` for plots.

## 📜 License
MIT License (see `LICENSE`). Data remains subject to the original Kaggle license.

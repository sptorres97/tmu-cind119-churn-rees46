# Data Sources & License

**Dataset:** REES46 E‑Commerce Churn (customer‑level)
- Host: Kaggle (Martin Fridrich)
- Link: https://www.kaggle.com/datasets/fridrichmrtn/e-commerce-churn-dataset-rees46
- Usage: Educational/research use per Kaggle terms. Cite the author/dataset when publishing.

> Do not commit full raw data to the repository. Store locally or reference Kaggle.
